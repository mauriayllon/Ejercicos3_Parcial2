package Ejercicios3.ej4_ChainOfResponsability;

public class Coronel implements IHandler {

    private IHandler next;

    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(String s) {
        if(s.equals("Desbloqueos")||s.equals("Manifestaciones")){
            System.out.println("Atención por el coronel");
        }else{
            this.next.criteriaHandler(s);
        }
    }
}