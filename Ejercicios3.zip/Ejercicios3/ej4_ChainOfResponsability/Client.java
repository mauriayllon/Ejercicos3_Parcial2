package Ejercicios3.ej4_ChainOfResponsability;

public class Client {
    public static void main (String [] args){
        ControlOrdenes controlOrdenes = new ControlOrdenes();
        controlOrdenes.criteriaHandler("Limpiezas");
        controlOrdenes.criteriaHandler("Entrevistas");
        controlOrdenes.criteriaHandler("Manifestaciones");
        controlOrdenes.criteriaHandler("Disciplina");
    }
}
