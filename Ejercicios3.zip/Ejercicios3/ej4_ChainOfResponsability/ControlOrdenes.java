package Ejercicios3.ej4_ChainOfResponsability;

public class ControlOrdenes implements IHandler {
    private IHandler next;
    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(String s) {
        General general = new General();
        Teniente teniente = new Teniente();
        Coronel coronel = new Coronel();
        Cabo cabo = new Cabo();


        this.setNext(general);
        general.setNext(teniente);
        teniente.setNext(coronel);
        coronel.setNext(cabo);

        this.next.criteriaHandler(s);
    }
}