package Ejercicios3.ej4_ChainOfResponsability;

public interface IHandler {
    void setNext(IHandler handler);
    IHandler next();
    void criteriaHandler(String s);   // nuestra peticion
}
