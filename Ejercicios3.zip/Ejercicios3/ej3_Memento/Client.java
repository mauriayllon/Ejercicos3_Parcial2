package Ejercicios3.ej3_Memento;

public class Client {
    public  static  void main (String[]args){
        Revision revision = new Revision();
        Tutor tutor= new Tutor();

        Tesis tesis;

        tesis= new Tesis("Version1",1);
        tutor.setTesis(tesis);
        revision.addMemento(tesis.getID(),tutor.createMemento());

        tesis= new Tesis("Version2",2);
        tutor.setTesis(tesis);
        revision.addMemento(tesis.getID(),tutor.createMemento());

        tesis= new Tesis("Version3",3);
        tutor.setTesis(tesis);
        revision.addMemento(tesis.getID(),tutor.createMemento());

        tesis= new Tesis("Version4",4);
        tutor.setTesis(tesis);
        revision.addMemento(tesis.getID(),tutor.createMemento());

        tesis= new Tesis("Version5",5);
        tutor.setTesis(tesis);
        revision.addMemento(tesis.getID(),tutor.createMemento());

        tutor.restoreFromMemento(revision.getMemento(3));
    }
}
