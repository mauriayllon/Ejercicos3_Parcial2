package Ejercicios3.ej3_Memento;

import java.util.HashMap;

public class Revision {
    private HashMap<Integer,Memento> savedStates = new HashMap<>();

    public void addMemento(int i,Memento memento) {
        this.savedStates.put(i,memento);
    }

    public Memento getMemento(int i) {
        return this.savedStates.get(i);
    }
}
