package Ejercicios3.ej3_Memento;

public class Memento {
    private Tesis tesis;

    public Memento(Tesis tesis) {
        this.tesis = tesis;
    }

    public Tesis getTesis() {
        return tesis;
    }

    public void setTesis(Tesis tesis) {
        this.tesis = tesis;
    }
}
