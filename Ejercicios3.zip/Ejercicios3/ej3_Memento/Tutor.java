package Ejercicios3.ej3_Memento;

import java.util.HashMap;

public class Tutor {
    private Tesis tesis;

    public Tesis getTesis() {
        return tesis;
    }

    public void setTesis(Tesis tesis) {
        System.out.println("Set ----> Object -----");
        tesis.showData();
        this.tesis = tesis;
    }


    public Memento createMemento(){
        System.out.println("Create ---->  Object  -----");
        tesis.showData();
        return new Memento(this.tesis);
    }

    public void restoreFromMemento(Memento n){
        this.tesis= n.getTesis();
        System.out.println("Restore --- > Object  ");
        this.tesis.showData();
    }

}
