package Ejercicios3.ej3_Memento;

public class Tesis {
    private String contenido;
    private int ID;

    public Tesis(String contenido, int ID) {
        this.contenido = contenido;
        this.ID = ID;
    }

    public void showData(){
        System.out.println("ID: "+this.ID);
        System.out.println("Contenido: "+this.contenido);
    }
    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
