package Ejercicios3.ej2_ChainOfResponsability;

public class Carnetizacion implements IHandler {

    private IHandler next;

    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(Persona p) {
    if(p.isFicha() && p.isCertificado() && p.isPagoAlBanco()){
        System.out.println("Usted cuenta con todos los requisitos, sera atendido por Carnetizacion");
    }else{
        this.next.criteriaHandler(p);
    }
    }
}