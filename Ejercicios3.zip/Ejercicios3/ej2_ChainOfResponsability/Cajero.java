package Ejercicios3.ej2_ChainOfResponsability;

public class Cajero implements IHandler {

    private IHandler next;

    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(Persona p) {
        if(p.isFicha() && p.isCertificado() && !p.isPagoAlBanco()){
            System.out.println("Usted no cuenta con el pago al banco tiene que ir al cajero");
        }else{
            this.next.criteriaHandler(p);
        }
    }
}