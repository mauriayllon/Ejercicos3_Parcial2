package Ejercicios3.ej2_ChainOfResponsability;

public class AtencionAlCliente implements IHandler {

    private IHandler next;

    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(Persona p) {
        if((!p.isFicha() && !p.isCertificado()) || (!p.isCertificado() && !p.isPagoAlBanco()) || (!p.isPagoAlBanco() && !p.isFicha()) ||(!p.isFicha() && !p.isCertificado() && !p.isPagoAlBanco()) ){
            System.out.println("Usted no cuenta que muchso requisitos sera atendido por Atención al Cliente");
        }
}}
