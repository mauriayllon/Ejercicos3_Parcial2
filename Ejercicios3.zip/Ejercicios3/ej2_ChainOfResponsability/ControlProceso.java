package Ejercicios3.ej2_ChainOfResponsability;

public class ControlProceso implements IHandler {
    private IHandler next;
    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(Persona p) {

        Carnetizacion carnetizacion = new Carnetizacion();
        Notario notario = new Notario();
        Cajero cajero = new Cajero();
        AtencionAlCliente atencionAlCliente = new AtencionAlCliente();

        this.setNext(carnetizacion);
        carnetizacion.setNext(notario);
        notario.setNext(cajero);
        cajero.setNext(atencionAlCliente);

        this.next.criteriaHandler(p);
    }
}