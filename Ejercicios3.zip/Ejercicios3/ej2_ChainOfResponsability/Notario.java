package Ejercicios3.ej2_ChainOfResponsability;

public class Notario implements IHandler {

    private IHandler next;

    @Override
    public void setNext(IHandler handler) {
        this.next=handler;
    }

    @Override
    public IHandler next() {
        return this.next;
    }

    @Override
    public void criteriaHandler(Persona p) {
        if(p.isFicha() && !p.isCertificado() && p.isPagoAlBanco()){
            System.out.println("Usted no cuenta con el certificado de nacimiento, tiene que ir al notario");
        }else{
            this.next.criteriaHandler(p);
        }
    }
}