package Ejercicios3.ej2_ChainOfResponsability;


public class Client {
    public static void main (String [] args){
        ControlProceso controlProceso = new ControlProceso();
        controlProceso.criteriaHandler(new Persona(true,true,true));
        controlProceso.criteriaHandler(new Persona(true,false,true));
        controlProceso.criteriaHandler(new Persona(false,true,true));
        controlProceso.criteriaHandler(new Persona(true,false, false));
    }}
