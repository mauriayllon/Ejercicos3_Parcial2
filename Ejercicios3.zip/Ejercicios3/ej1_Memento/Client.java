package Ejercicios3.ej1_Memento;

import java.util.ArrayList;
import java.util.List;

public class Client {
    public  static  void main (String[]args){
        Originator originator= new Originator();
        List <Persona> baseDeDatos = new ArrayList<>();
        BackUp backUp = new BackUp();

        baseDeDatos.add(new Persona(18,1232143,"Juan1"));
        //baseDeDatos.add(new Persona(19,1232143,"Juan2"));
        //baseDeDatos.add(new Persona(20,1232143,"Juan3"));
        originator.setPersonas(baseDeDatos);
        backUp.addMemento("BackUpFebrero",originator.createMemento());


        baseDeDatos.add(new Persona(21,1232143,"Juan4"));
        //baseDeDatos.add(new Persona(22,1232143,"Juan5"));
        //baseDeDatos.add(new Persona(23,1232143,"Juan6"));
        originator.setPersonas(baseDeDatos);
        backUp.addMemento("BackUpMarzo",originator.createMemento());

        baseDeDatos.add(new Persona(24,1232143,"Juan7"));
        //baseDeDatos.add(new Persona(25,1232143,"Juan8"));
        //baseDeDatos.add(new Persona(26,1232143,"Juan9"));
        originator.setPersonas(baseDeDatos);
        backUp.addMemento("BackUpAbril",originator.createMemento());

        baseDeDatos.add(new Persona(27,1232143,"Jua10"));
        //baseDeDatos.add(new Persona(28,1232143,"Juan11"));
        //baseDeDatos.add(new Persona(29,1232143,"Juan12"));
        originator.setPersonas(baseDeDatos);
        backUp.addMemento("BackUpMayo",originator.createMemento());

        baseDeDatos.add(new Persona(30,1232143,"Juan13"));
        //baseDeDatos.add(new Persona(31,1232143,"Juan14"));
        //baseDeDatos.add(new Persona(32,1232143,"Juan15"));
        originator.setPersonas(baseDeDatos);
        backUp.addMemento("BackUpJunio",originator.createMemento());

        originator.restoreFromMemento(backUp.getMemento("BackUpFebrero"));
    }
}
