package Ejercicios3.ej1_Memento;

public class Persona {
    int edad;
    int ci;
    String nombre;

    public Persona(int edad, int ci, String nombre) {
        this.edad = edad;
        this.ci = ci;
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
