package Ejercicios3.ej1_Memento;

import java.util.ArrayList;

public class BaseDeDatos {
    private ArrayList<Persona> personas = new ArrayList<>();

    public void add(Persona persona) {
        this.personas.add(persona);
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void showData(){
        for (int i = 0; i < personas.size() ; i++) {
            System.out.println("Nombre: "+ personas.get(i).getNombre()+" || CI: "+personas.get(i).getCi() + " || Edad " +personas.get(i).getEdad());
        }
    }
}
