package Ejercicios3.ej1_Memento;

import java.util.List;

public class Memento {

    List<Persona> personas;

    public Memento (List<Persona> personas){
        this.personas=personas;
    }

    public List<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(List<Persona> personas) {
        this.personas = personas;
    }


}
