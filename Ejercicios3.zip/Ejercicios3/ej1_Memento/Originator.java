package Ejercicios3.ej1_Memento;

import java.util.List;

public class Originator {
    List<Persona> personas;

    public List<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(List<Persona> personas) {
        this.personas = personas;
    }

    public Memento createMemento(){
        System.out.println("Guardando back up----->");
        for (int i = 0; i < personas.size() ; i++) {
            System.out.println("Nombre: "+ personas.get(i).getNombre()+" || CI: "+personas.get(i).getCi() + " || Edad " +personas.get(i).getEdad());

        }
        return new Memento(this.personas);
    }

    public void restoreFromMemento(Memento n){
        this.personas=n.getPersonas();
        System.out.println("Restaurando back up------>");
        for (int i = 0; i < this.personas.size() ; i++) {
            System.out.println("Nombre: "+ this.personas.get(i).getNombre()+" || CI: "+this.personas.get(i).getCi() + " || Edad " +this.personas.get(i).getEdad());
        }
    }

}